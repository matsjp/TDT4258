void setupTimer (uint32_t period);
void setupDAC ();
void setupGPIO ();

void startTimer ();
extern void playSound ();

extern uint16_t sound1;
extern uint16_t sound2;
extern uint16_t sound3;
extern uint16_t intro;
