extern uint16_t sound1;
extern uint16_t sound2;
extern uint16_t sound3;
extern uint16_t intro;

extern volatile int soundLength;
extern volatile uint16_t *soundPointer;
extern volatile int nextSound;
extern volatile int soundIsPlaying;
